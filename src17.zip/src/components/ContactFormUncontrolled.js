import React, { useRef } from 'react';
import './UserRegistrationForm.css';

const ContactFormUncontrolled = () => {
  const formRef = useRef(null);
  const nameRef = useRef(null);
  const emailRef = useRef(null);
  const messageRef = useRef(null);
  const categoryRef = useRef(null);
  const priorityRef = useRef(null);

  const handleSubmit = (e) => {
    e.preventDefault();

    const formData = {
      name: nameRef.current.value,
      email: emailRef.current.value,
      message: messageRef.current.value,
      category: categoryRef.current.value,
      priority: priorityRef.current.checked
    };

    console.log('Данные формы (неуправляемая):', formData);
    alert('Форма обратной связи отправлена! Проверьте консоль.');

    // Сброс формы
    formRef.current.reset();
  };

  return (
    <div className="form-container">
      <h2>Форма обратной связи (неуправляемая)</h2>
      <form ref={formRef} onSubmit={handleSubmit} className="registration-form">
        <div className="form-group">
          <label htmlFor="uncontrolled-name">Имя:</label>
          <input
            type="text"
            id="uncontrolled-name"
            ref={nameRef}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="uncontrolled-email">Email:</label>
          <input
            type="email"
            id="uncontrolled-email"
            ref={emailRef}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="uncontrolled-category">Категория:</label>
          <select
            id="uncontrolled-category"
            ref={categoryRef}
            required
          >
            <option value="">Выберите категорию</option>
            <option value="technical">Техническая поддержка</option>
            <option value="sales">Вопросы по продажам</option>
            <option value="general">Общие вопросы</option>
            <option value="feedback">Обратная связь</option>
          </select>
        </div>

        <div className="form-group">
          <label className="checkbox-label">
            <input
              type="checkbox"
              ref={priorityRef}
            />
            Срочный вопрос
          </label>
        </div>

        <div className="form-group">
          <label htmlFor="uncontrolled-message">Сообщение:</label>
          <textarea
            id="uncontrolled-message"
            ref={messageRef}
            rows="4"
            required
          />
        </div>

        <button type="submit" className="submit-btn">
          Отправить сообщение
        </button>
      </form>
    </div>
  );
};

export default ContactFormUncontrolled;