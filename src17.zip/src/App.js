import React, { useState } from 'react';
import UserRegistrationForm from './components/UserRegistrationForm';
import UserRegistrationFormWithValidation from './components/UserRegistrationFormWithValidation';
import ContactFormUncontrolled from './components/ContactFormUncontrolled';
import './App.css';

function App() {
  const [activeForm, setActiveForm] = useState('basic');

  const renderForm = () => {
    switch (activeForm) {
      case 'basic':
        return <UserRegistrationForm />;
      case 'validation':
        return <UserRegistrationFormWithValidation />;
      case 'uncontrolled':
        return <ContactFormUncontrolled />;
      default:
        return <UserRegistrationForm />;
    }
  };

  return (
    <div className="App">
      <header className="App-header">
        <h1>React Forms - Практическая работа №17</h1>
        <nav className="navigation">
          <button 
            onClick={() => setActiveForm('basic')}
            className={activeForm === 'basic' ? 'active' : ''}
          >
            Базовая форма
          </button>
          <button 
            onClick={() => setActiveForm('validation')}
            className={activeForm === 'validation' ? 'active' : ''}
          >
            Форма с валидацией
          </button>
          <button 
            onClick={() => setActiveForm('uncontrolled')}
            className={activeForm === 'uncontrolled' ? 'active' : ''}
          >
            Неуправляемая форма
          </button>
        </nav>
      </header>
      <main>
        {renderForm()}
      </main>
    </div>
  );
}

export default App;
