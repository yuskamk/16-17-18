import React, { useReducer, useContext, useCallback, useMemo, useRef, memo } from 'react';
import './AdvancedHooks.css';

// Контекст для useContext
const ThemeContext = React.createContext();

// Редуктор для useReducer
const counterReducer = (state, action) => {
  switch (action.type) {
    case 'INCREMENT':
      return { count: state.count + 1 };
    case 'DECREMENT':
      return { count: state.count - 1 };
    case 'RESET':
      return { count: 0 };
    case 'SET':
      return { count: action.payload };
    default:
      return state;
  }
};

// Мемоизированный дочерний компонент
const ExpensiveComponent = memo(({ value, onCalculate }) => {
  console.log('ExpensiveComponent перерендерен');
  return (
    <div className="expensive-component">
      <p>Результат вычисления: {onCalculate(value)}</p>
      <p>Значение: {value}</p>
    </div>
  );
});

const AdvancedHooks = () => {
  // useReducer - для сложного состояния
  const [state, dispatch] = useReducer(counterReducer, { count: 0 });

  // useContext - доступ к контексту
  const theme = useContext(ThemeContext);

  // useRef - ссылки на DOM и изменяемые значения
  const inputRef = useRef(null);
  const renderCount = useRef(0);

  renderCount.current++;

  // useCallback - мемоизация функций
  const expensiveCalculation = useCallback((num) => {
    console.log('Выполняется дорогое вычисление...');
    // Имитация тяжелых вычислений
    let result = 0;
    for (let i = 0; i < 1000000; i++) {
      result += num * i;
    }
    return result;
  }, []);

  // useMemo - мемоизация значений
  const memoizedValue = useMemo(() => {
    return expensiveCalculation(5);
  }, [expensiveCalculation]);

  const handleIncrement = () => dispatch({ type: 'INCREMENT' });
  const handleDecrement = () => dispatch({ type: 'DECREMENT' });
  const handleReset = () => dispatch({ type: 'RESET' });
  const handleSet = () => {
    const value = parseInt(inputRef.current?.value) || 0;
    dispatch({ type: 'SET', payload: value });
  };

  const focusInput = () => {
    inputRef.current?.focus();
  };

  return (
    <div className={`advanced-hooks ${theme}`}>
      <h2>Продвинутые хуки React</h2>

      <div className="section">
        <h3>useReducer: Управление состоянием</h3>
        <p>Счетчик: {state.count}</p>
        <div className="button-group">
          <button onClick={handleIncrement}>+1</button>
          <button onClick={handleDecrement}>-1</button>
          <button onClick={handleReset}>Сброс</button>
        </div>
      </div>

      <div className="section">
        <h3>useRef: Ссылки и мутируемые значения</h3>
        <div className="input-group">
          <input
            ref={inputRef}
            type="number"
            placeholder="Установить значение"
          />
          <button onClick={handleSet}>Установить</button>
          <button onClick={focusInput}>Фокус на input</button>
        </div>
        <p>Компонент перерендерен: {renderCount.current} раз</p>
      </div>

      <div className="section">
        <h3>useCallback и useMemo: Оптимизация</h3>
        <p>Мемоизированное значение: {memoizedValue}</p>
        <ExpensiveComponent 
          value={state.count} 
          onCalculate={expensiveCalculation} 
        />
      </div>

      <div className="section">
        <h3>useContext: Темы</h3>
        <p>Текущая тема: {theme}</p>
      </div>
    </div>
  );
};

// Обертка с провайдером контекста
const AdvancedHooksWithProvider = () => {
  return (
    <ThemeContext.Provider value="light-theme">
      <AdvancedHooks />
    </ThemeContext.Provider>
  );
};

export default AdvancedHooksWithProvider;