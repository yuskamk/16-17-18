import React, { useState, useEffect, useRef } from 'react';
import './HooksTests.css';

const HooksTests = () => {
  const [testResults, setTestResults] = useState({});
  const [currentTest, setCurrentTest] = useState('');
  const renderCount = useRef(0);

  renderCount.current++;

  const tests = {
    useState: () => {
      const [value, setValue] = useState(0);
      return `useState работает: ${value}`;
    },
    
    useEffect: () => {
      const [effectRun, setEffectRun] = useState(false);
      useEffect(() => {
        setEffectRun(true);
      }, []);
      return `useEffect работает: ${effectRun}`;
    },
    
    useReducer: () => {
      const reducer = (state, action) => {
        switch (action.type) {
          case 'TEST': return { ...state, test: 'passed' };
          default: return state;
        }
      };
      const [state] = React.useReducer(reducer, { test: 'initial' });
      return `useReducer работает: ${state.test}`;
    },
    
    useContext: () => {
      const TestContext = React.createContext('default');
      const value = React.useContext(TestContext);
      return `useContext работает: ${value}`;
    },
    
    useCallback: () => {
      const callback = React.useCallback(() => 'test', []);
      return `useCallback работает: ${callback()}`;
    },
    
    useMemo: () => {
      const memoized = React.useMemo(() => 'memoized', []);
      return `useMemo работает: ${memoized}`;
    },
    
    useRef: () => {
      const ref = useRef('refValue');
      return `useRef работает: ${ref.current}`;
    }
  };

  const runTest = (testName) => {
    try {
      setCurrentTest(testName);
      const result = tests[testName]();
      setTestResults(prev => ({
        ...prev,
        [testName]: { status: 'success', message: result }
      }));
    } catch (error) {
      setTestResults(prev => ({
        ...prev,
        [testName]: { status: 'error', message: error.message }
      }));
    }
  };

  const runAllTests = () => {
    Object.keys(tests).forEach(testName => {
      runTest(testName);
    });
  };

  return (
    <div className="hooks-tests">
      <h2>Тестирование React хуков</h2>
      
      <div className="test-info">
        <p>Компонент перерендерен: {renderCount.current} раз</p>
        <button onClick={runAllTests} className="run-all-btn">
          Запустить все тесты
        </button>
      </div>

      <div className="test-buttons">
        {Object.keys(tests).map(testName => (
          <button
            key={testName}
            onClick={() => runTest(testName)}
            className={`test-btn ${
              testResults[testName]?.status === 'success' ? 'success' : 
              testResults[testName]?.status === 'error' ? 'error' : ''
            }`}
          >
            {testName}
          </button>
        ))}
      </div>

      <div className="test-results">
        <h3>Результаты тестов:</h3>
        {currentTest && (
          <p>Выполняется тест: <strong>{currentTest}</strong></p>
        )}
        {Object.entries(testResults).map(([testName, result]) => (
          <div key={testName} className={`test-result ${result.status}`}>
            <strong>{testName}:</strong> {result.message}
          </div>
        ))}
      </div>

      <div className="hooks-rules">
        <h3>Правила хуков:</h3>
        <ul>
          <li>✓ Вызывайте хуки только на верхнем уровне</li>
          <li>✓ Вызывайте хуки только из React-функций</li>
          <li>✓ Не вызывайте хуки внутри условий, циклов или вложенных функций</li>
          <li>✓ Следуйте соглашению об именовании кастомных хуков (use*)</li>
        </ul>
      </div>
    </div>
  );
};

export default HooksTests;