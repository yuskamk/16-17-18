import React, { useState, useEffect, useCallback } from 'react';
import './CustomHooks.css';

// Кастомный хук для localStorage
const useLocalStorage = (key, initialValue) => {
  const [value, setValue] = useState(() => {
    try {
      const item = window.localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch (error) {
      console.error(`Ошибка чтения localStorage ключа "${key}":`, error);
      return initialValue;
    }
  });

  const setStoredValue = useCallback((newValue) => {
    try {
      setValue(newValue);
      window.localStorage.setItem(key, JSON.stringify(newValue));
    } catch (error) {
      console.error(`Ошибка записи в localStorage ключа "${key}":`, error);
    }
  }, [key]);

  return [value, setStoredValue];
};

// Кастомный хук для API запросов
const useApi = (url) => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        setError(null);
        const response = await fetch(url);
        if (!response.ok) {
          throw new Error(`HTTP ошибка! статус: ${response.status}`);
        }
        const result = await response.json();
        setData(result);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [url]);

  return { data, loading, error };
};

// Кастомный хук для отслеживания размера окна
const useWindowSize = () => {
  const [windowSize, setWindowSize] = useState({
    width: window.innerWidth,
    height: window.innerHeight,
  });

  useEffect(() => {
    const handleResize = () => {
      setWindowSize({
        width: window.innerWidth,
        height: window.innerHeight,
      });
    };

    window.addEventListener('resize', handleResize);
    
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return windowSize;
};

// Кастомный хук для таймера
const useTimer = (initialTime = 0) => {
  const [time, setTime] = useState(initialTime);
  const [isRunning, setIsRunning] = useState(false);

  useEffect(() => {
    let intervalId;

    if (isRunning) {
      intervalId = setInterval(() => {
        setTime(prevTime => prevTime + 1);
      }, 1000);
    }

    return () => {
      if (intervalId) {
        clearInterval(intervalId);
      }
    };
  }, [isRunning]);

  const start = () => setIsRunning(true);
  const pause = () => setIsRunning(false);
  const reset = () => {
    setIsRunning(false);
    setTime(initialTime);
  };

  return { time, isRunning, start, pause, reset };
};

// Компонент использующий кастомные хуки
const CustomHooks = () => {
  // Использование кастомного хука localStorage
  const [name, setName] = useLocalStorage('userName', '');
  const [theme, setTheme] = useLocalStorage('theme', 'light');

  // Использование кастомного хука API
  const { data: user, loading, error } = useApi('https://jsonplaceholder.typicode.com/users/1');

  // Использование кастомного хука размера окна
  const windowSize = useWindowSize();

  // Использование кастомного хука таймера
  const { time, isRunning, start, pause, reset } = useTimer();

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className={`custom-hooks ${theme}`}>
      <h2>Кастомные хуки React</h2>

      <div className="section">
        <h3>useLocalStorage: Сохранение в localStorage</h3>
        <div className="input-group">
          <input
            type="text"
            placeholder="Введите ваше имя"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
          <p>Привет, {name || 'незнакомец'}!</p>
        </div>
        <div className="theme-buttons">
          <button 
            onClick={() => setTheme('light')}
            className={theme === 'light' ? 'active' : ''}
          >
            Светлая тема
          </button>
          <button 
            onClick={() => setTheme('dark')}
            className={theme === 'dark' ? 'active' : ''}
          >
            Темная тема
          </button>
        </div>
      </div>

      <div className="section">
        <h3>useApi: Запросы к API</h3>
        {loading && <p>Загрузка...</p>}
        {error && <p className="error">Ошибка: {error}</p>}
        {user && (
          <div className="user-info">
            <p><strong>Имя:</strong> {user.name}</p>
            <p><strong>Email:</strong> {user.email}</p>
            <p><strong>Телефон:</strong> {user.phone}</p>
          </div>
        )}
      </div>

      <div className="section">
        <h3>useWindowSize: Размер окна</h3>
        <p>Ширина окна: {windowSize.width}px</p>
        <p>Высота окна: {windowSize.height}px</p>
      </div>

      <div className="section">
        <h3>useTimer: Таймер</h3>
        <p className="timer">{formatTime(time)}</p>
        <div className="button-group">
          <button onClick={start} disabled={isRunning}>
            Старт
          </button>
          <button onClick={pause} disabled={!isRunning}>
            Пауза
          </button>
          <button onClick={reset}>
            Сброс
          </button>
        </div>
        <p>Статус: {isRunning ? 'Запущен' : 'Остановлен'}</p>
      </div>
    </div>
  );
};

export default CustomHooks;