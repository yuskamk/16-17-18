import React, { useState, useEffect } from 'react';
import './BasicHooks.css';

const BasicHooks = () => {
  // useState - управление состоянием
  const [count, setCount] = useState(0);
  const [name, setName] = useState('');
  const [isVisible, setIsVisible] = useState(true);

  // useEffect - побочные эффекты
  useEffect(() => {
    console.log('Компонент смонтирован');
    
    return () => {
      console.log('Компонент будет размонтирован');
    };
  }, []);

  useEffect(() => {
    document.title = `Счетчик: ${count}`;
    console.log(`Счетчик обновлен: ${count}`);
  }, [count]);

  useEffect(() => {
    if (name) {
      console.log(`Имя изменено на: ${name}`);
    }
  }, [name]);

  const increment = () => setCount(prevCount => prevCount + 1);
  const decrement = () => setCount(prevCount => prevCount - 1);
  const reset = () => setCount(0);
  const toggleVisibility = () => setIsVisible(prev => !prev);

  return (
    <div className="basic-hooks">
      <h2>Базовые хуки React</h2>
      
      <div className="counter-section">
        <h3>useState: Счетчик</h3>
        <p>Текущее значение: {count}</p>
        <div className="button-group">
          <button onClick={increment}>+1</button>
          <button onClick={decrement}>-1</button>
          <button onClick={reset}>Сброс</button>
        </div>
      </div>

      <div className="input-section">
        <h3>useState: Форма</h3>
        <input
          type="text"
          placeholder="Введите ваше имя"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        {name && <p>Привет, {name}!</p>}
      </div>

      <div className="toggle-section">
        <h3>useState: Переключение</h3>
        <button onClick={toggleVisibility}>
          {isVisible ? 'Скрыть' : 'Показать'}
        </button>
        {isVisible && (
          <div className="visible-content">
            <p>Этот контент видим!</p>
          </div>
        )}
      </div>

      <div className="effect-section">
        <h3>useEffect: Эффекты</h3>
        <p>Откройте консоль разработчика чтобы увидеть логи useEffect</p>
        <ul>
          <li>Заголовок страницы обновляется при изменении счетчика</li>
          <li>Логируются изменения имени</li>
          <li>Есть cleanup функция при размонтировании</li>
        </ul>
      </div>
    </div>
  );
};

export default BasicHooks;