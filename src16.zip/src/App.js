import React, { useState } from 'react';
import BasicHooks from './components/BasicHooks';
import AdvancedHooks from './components/AdvancedHooks';
import CustomHooks from './components/CustomHooks';
import HooksTests from './components/HooksTests';
import './App.css';

function App() {
  const [currentSection, setCurrentSection] = useState('basic');

  const renderSection = () => {
    switch (currentSection) {
      case 'basic':
        return <BasicHooks />;
      case 'advanced':
        return <AdvancedHooks />;
      case 'custom':
        return <CustomHooks />;
      case 'tests':
        return <HooksTests />;
      default:
        return <BasicHooks />;
    }
  };

  return (
    <div className="App">
      <header className="App-header">
        <h1>React Hooks Практика</h1>
        <nav className="navigation">
          <button 
            onClick={() => setCurrentSection('basic')}
            className={currentSection === 'basic' ? 'active' : ''}
          >
            Базовые хуки
          </button>
          <button 
            onClick={() => setCurrentSection('advanced')}
            className={currentSection === 'advanced' ? 'active' : ''}
          >
            Продвинутые хуки
          </button>
          <button 
            onClick={() => setCurrentSection('custom')}
            className={currentSection === 'custom' ? 'active' : ''}
          >
            Кастомные хуки
          </button>
          <button 
            onClick={() => setCurrentSection('tests')}
            className={currentSection === 'tests' ? 'active' : ''}
          >
            Тестирование
          </button>
        </nav>
      </header>

      <main className="App-main">
        {renderSection()}
      </main>

      <footer className="App-footer">
        <p>Практическая работа №16: «React: использование хуков»</p>
      </footer>
    </div>
  );
}

export default App;
