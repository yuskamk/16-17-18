import React from 'react';
import { Link } from 'react-router-dom';

const Services = () => {
  const services = [
    {
      id: 1,
      name: 'Стрижка и укладка',
      price: 'от 1500 ₽',
      duration: '1-2 часа',
      description: 'Профессиональная стрижка и стильная укладка'
    },
    {
      id: 2,
      name: 'Маникюр',
      price: 'от 1200 ₽',
      duration: '1.5 часа',
      description: 'Классический, аппаратный или комбинированный маникюр'
    },
    {
      id: 3,
      name: 'Педикюр',
      price: 'от 1800 ₽',
      duration: '1.5 часа',
      description: 'Ухоженные ножки в любое время года'
    },
    {
      id: 4,
      name: 'Косметология',
      price: 'от 2500 ₽',
      duration: '2 часа',
      description: 'Профессиональный уход за кожей лица'
    },
    {
      id: 5,
      name: 'Макияж',
      price: 'от 2000 ₽',
      duration: '1.5 часа',
      description: 'Дневной, вечерний или свадебный макияж'
    },
    {
      id: 6,
      name: 'Массаж',
      price: 'от 2200 ₽',
      duration: '1 час',
      description: 'Расслабляющий и оздоровительный массаж'
    }
  ];

  return (
    <div className="services">
      <h1>Наши услуги</h1>
      <div className="services-grid">
        {services.map(service => (
          <div key={service.id} className="service-card">
            <h3>{service.name}</h3>
            <p className="service-price">{service.price}</p>
            <p className="service-duration">⏱️ {service.duration}</p>
            <p className="service-description">{service.description}</p>
            <Link to={`/services/${service.id}`} className="service-link">
              Подробнее
            </Link>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Services;