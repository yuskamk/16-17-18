import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const Contact = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    service: '',
    date: '',
    message: ''
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // В реальном приложении здесь был бы запрос к API
    console.log('Данные формы:', formData);
    
    // Переход на страницу успеха с состоянием
    navigate('/contact/success', { 
      state: { 
        name: formData.name,
        service: formData.service,
        date: formData.date
      } 
    });
  };

  return (
    <div className="contact">
      <h1>Запись на услугу</h1>
      <div className="contact-content">
        <div className="contact-info">
          <h3>Контактная информация</h3>
          <p>📍 г. Москва, ул. Красоты, 15</p>
          <p>📞 +7 (495) 123-45-67</p>
          <p>✉️ info@siyai-beauty.ru</p>
          <p>🕒 Ежедневно с 9:00 до 21:00</p>
        </div>
        
        <form onSubmit={handleSubmit} className="contact-form">
          <div className="form-group">
            <label htmlFor="name">Имя *</label>
            <input
              type="text"
              id="name"
              name="name"
              value={formData.name}
              onChange={handleChange}
              required
            />
          </div>
          
          <div className="form-group">
            <label htmlFor="phone">Телефон *</label>
            <input
              type="tel"
              id="phone"
              name="phone"
              value={formData.phone}
              onChange={handleChange}
              required
            />
          </div>
          
          <div className="form-group">
            <label htmlFor="email">Email</label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
            />
          </div>
          
          <div className="form-group">
            <label htmlFor="service">Услуга</label>
            <select
              id="service"
              name="service"
              value={formData.service}
              onChange={handleChange}
            >
              <option value="">Выберите услугу</option>
              <option value="Стрижка и укладка">Стрижка и укладка</option>
              <option value="Маникюр">Маникюр</option>
              <option value="Педикюр">Педикюр</option>
              <option value="Косметология">Косметология</option>
              <option value="Макияж">Макияж</option>
              <option value="Массаж">Массаж</option>
            </select>
          </div>
          
          <div className="form-group">
            <label htmlFor="date">Желаемая дата</label>
            <input
              type="date"
              id="date"
              name="date"
              value={formData.date}
              onChange={handleChange}
            />
          </div>
          
          <div className="form-group">
            <label htmlFor="message">Дополнительная информация</label>
            <textarea
              id="message"
              name="message"
              rows="4"
              value={formData.message}
              onChange={handleChange}
            ></textarea>
          </div>
          
          <button type="submit" className="submit-button">
            Отправить заявку
          </button>
        </form>
      </div>
    </div>
  );
};

export default Contact;