import React from 'react';
import { Link } from 'react-router-dom';

const Home = () => {
  return (
    <div className="home">
      <section className="hero">
        <h1>Добро пожаловать в салон красоты "Сияй"</h1>
        <p>Мы поможем вам раскрыть вашу природную красоту</p>
        <Link to="/services" className="cta-button">
          Наши услуги
        </Link>
      </section>
      
      <section className="features">
        <div className="feature-card">
          <h3>Профессионализм</h3>
          <p>Опытные мастера с многолетним стажем</p>
        </div>
        <div className="feature-card">
          <h3>Качество</h3>
          <p>Используем только сертифицированную косметику</p>
        </div>
        <div className="feature-card">
          <h3>Комфорт</h3>
          <p>Уютная атмосфера и индивидуальный подход</p>
        </div>
      </section>
    </div>
  );
};

export default Home;