import React from 'react';
import { useLocation, Link } from 'react-router-dom';

const ContactSuccess = () => {
  const location = useLocation();
  const { name, service, date } = location.state || {};

  return (
    <div className="contact-success">
      <div className="success-card">
        <div className="success-icon">✅</div>
        <h1>Заявка отправлена успешно!</h1>
        <p>Спасибо за вашу заявку, {name || 'клиент'}!</p>
        
        {service && (
          <p>
            <strong>Услуга:</strong> {service}
          </p>
        )}
        
        {date && (
          <p>
            <strong>Желаемая дата:</strong> {new Date(date).toLocaleDateString('ru-RU')}
          </p>
        )}
        
        <p>
          Наш администратор свяжется с вами в ближайшее время для подтверждения записи.
        </p>
        
        <div className="success-actions">
          <Link to="/" className="cta-button">
            На главную
          </Link>
          <Link to="/services" className="secondary-button">
            Посмотреть другие услуги
          </Link>
        </div>
      </div>
    </div>
  );
};

export default ContactSuccess;