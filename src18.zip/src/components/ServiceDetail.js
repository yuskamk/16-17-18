import React from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';

const ServiceDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const services = {
    1: {
      name: 'Стрижка и укладка',
      price: 'от 1500 ₽',
      duration: '1-2 часа',
      fullDescription: 'Наши стилисты подберут идеальную стрижку, учитывая форму вашего лица, тип волос и пожелания по уходу. Мы используем профессиональные средства для укладки, которые защищают волосы от термического воздействия.',
      includes: [
        'Консультация стилиста',
        'Мытье головы с профессиональным шампунем',
        'Стрижка',
        'Укладка с термозащитой',
        'Финальная фиксация'
      ]
    },
    2: {
      name: 'Маникюр',
      price: 'от 1200 ₽',
      duration: '1.5 часа',
      fullDescription: 'Профессиональный уход за руками и ногтями. Мы предлагаем различные виды маникюра в зависимости от ваших предпочтений и состояния ногтей.',
      includes: [
        'Аппаратная или классическая обработка',
        'Придание формы',
        'Уход за кутикулой',
        'Покрытие лаком/гель-лаком',
        'Питание кожи рук'
      ]
    },
    3: {
      name: 'Педикюр',
      price: 'от 1800 ₽',
      duration: '1.5 часа',
      fullDescription: 'Комплексный уход за стопами и ногтями ног. Особое внимание уделяется здоровью стоп и эстетическому виду.',
      includes: [
        'Обработка стоп',
        'Работа с ногтевыми пластинами',
        'Уход за кутикулой',
        'Пилинг и питание кожи',
        'Массаж стоп'
      ]
    },
    4: {
      name: 'Косметология',
      price: 'от 2500 ₽',
      duration: '2 часа',
      fullDescription: 'Профессиональные косметологические процедуры для здоровья и молодости вашей кожи. Индивидуальный подбор ухода.',
      includes: [
        'Диагностика кожи',
        'Очищение',
        'Пилинг (при необходимости)',
        'Основная уходовая процедура',
        'Нанесение сыворотки и крема'
      ]
    },
    5: {
      name: 'Макияж',
      price: 'от 2000 ₽',
      duration: '1.5 часа',
      fullDescription: 'Создание идеального образа для любого мероприятия. Наш визажист подберет цвета и технику, подчеркивающие ваши достоинства.',
      includes: [
        'Консультация по образу',
        'Подготовка кожи',
        'Тональная основа',
        'Работа с глазами и бровями',
        'Финальные штрихи'
      ]
    },
    6: {
      name: 'Массаж',
      price: 'от 2200 ₽',
      duration: '1 час',
      fullDescription: 'Расслабляющий и оздоровительный массаж от профессионального массажиста. Снимает напряжение и улучшает самочувствие.',
      includes: [
        'Консультация',
        'Подготовка',
        'Основная массажная техника',
        'Работа с проблемными зонами',
        'Завершающие движения'
      ]
    }
  };

  const service = services[id];

  if (!service) {
    return (
      <div className="service-detail">
        <h2>Услуга не найдена</h2>
        <Link to="/services">Вернуться к услугам</Link>
      </div>
    );
  }

  return (
    <div className="service-detail">
      <button onClick={() => navigate(-1)} className="back-button">
        ← Назад
      </button>
      
      <h1>{service.name}</h1>
      <div className="service-info">
        <div className="service-meta">
          <p><strong>Стоимость:</strong> {service.price}</p>
          <p><strong>Длительность:</strong> {service.duration}</p>
        </div>
        
        <div className="service-full-description">
          <h3>Описание услуги</h3>
          <p>{service.fullDescription}</p>
        </div>
        
        <div className="service-includes">
          <h3>В услугу входит:</h3>
          <ul>
            {service.includes.map((item, index) => (
              <li key={index}>{item}</li>
            ))}
          </ul>
        </div>
      </div>
      
      <div className="action-buttons">
        <Link to="/contact" className="cta-button">
          Записаться на услугу
        </Link>
        <Link to="/services" className="secondary-button">
          Все услуги
        </Link>
      </div>
    </div>
  );
};

export default ServiceDetail;